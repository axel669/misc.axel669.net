<script>
    import {
        Text,
        wsx
    } from "@axel669/svelte-wind"
</script>

<svelte:body use:wsx={{ theme: "tron", "@app": true }} />
