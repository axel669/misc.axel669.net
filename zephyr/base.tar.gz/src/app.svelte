<script>
    import {
        Text,
        wsx
    } from "@axel669/zephyr"
</script>

<svelte:body use:wsx={{ theme: "tron", "@app": true }} />

<Text>
    Ready!
</Text>
